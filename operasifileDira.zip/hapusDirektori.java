import java.io.File;

public class hapusDirektori {
    public static void main(String[] args) {
        //membuat objek File untuk direktori yang akan dihapus
        File direktori = new File("C:\\sampah");

        // Memastikan direktori ada dan merupakan direktori
        if (direktori.exists() && direktori.isDirectory()) {
            // Mendapatkan daftar file di dalam direktori
            File[] files = direktori.listFiles();
            // Memastikan daftar file tidak null
            if (files != null) {
                // untuk menandai apakah semua file berhasil dihapus
                boolean semuaFileTerhapus = true;
                for (File file : files) {
                    // Memastikan elemen saat ini adalah file
                    if (file.isFile()) {
                        // Mencoba menghapus file
                        if (!file.delete()) {
                            // Menampilkan pesan error jika penghapusan file gagal
                            System.err.println("Gagal menghapus file: " + file.getName());
                            // Mengubah flag menjadi false karena ada file yang gagal dihapus
                            semuaFileTerhapus = false;
                        }
                    }
                }

                // kalau semua file berhasil dihapus
                if (semuaFileTerhapus) {
                    // menghapus direktori
                    if (direktori.delete()) {
                        // pesan berhasil jika direktori berhasil dihapus
                        System.out.println("Direktori '" + direktori.getName() + "' berhasil dihapus.");
                    } else {
                        // pesan error jika penghapusan direktori gagal
                        System.err.println("Gagal menghapus direktori '" + direktori.getName() + "'.");
                    }
                } else {
                    // pesan error jika tidak semua file berhasil dihapus
                    System.err.println("Tidak semua file di dalam direktori berhasil dihapus. Direktori tidak dihapus.");
                }
            } else {
                // Jika direktori kosong
                System.out.println("Direktori kosong.");
                // Mencoba menghapus direktori kosong
                if (direktori.delete()) {
                    // pesan sukses jika direktori berhasil dihapus
                    System.out.println("Direktori '" + direktori.getName() + "' berhasil dihapus.");
                } else {
                    // pesan error jika penghapusan direktori gagal
                    System.err.println("Gagal menghapus direktori '" + direktori.getName() + "'.");
                }
            }
        } else {
            // Jika direktori tidak ada atau bukan direktori
            System.out.println("Direktori '" + direktori.getName() + "' tidak ada atau bukan direktori.");
        }
    }
}