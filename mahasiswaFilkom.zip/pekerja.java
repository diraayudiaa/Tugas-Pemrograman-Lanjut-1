import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

// class pekerja inheritance dari manusia
public class pekerja extends manusia {
    // informasi gaji pokok pekerja
    private double nominalGaji;

    // tanggal saat pekerja mulai bekerja
    private LocalDate tanggalMasuk;

    // jumlah anak yang dimiliki pekerja
    private int anak;

    // Konstruktor pekerja untuk menginisialisasi semua atribut yang dibutuhkan, termasuk dari superclass
    public pekerja (String nama, boolean jenisKelamin, String nik, boolean menikah, double gaji, LocalDate masuk, int anak) {
        super(nama, jenisKelamin, nik, menikah); // Memanggil konstruktor dari kelas manusia
        this.nominalGaji = gaji;
        this.tanggalMasuk = masuk;
        this.anak = anak;
    }

    // untuk menghitung bonus tahunan berdasarkan lama masa kerja
    public double bonusTahunan() {
        // selisih tahun dari tanggal masuk hingga sekarang
        long tahunKerja = ChronoUnit.YEARS.between(tanggalMasuk, LocalDate.now());

        // Bonus bertingkat tergantung durasi kerja
        if (tahunKerja <= 5) return 0.05 * nominalGaji; // ≤5 tahun: 5% bonus
        if (tahunKerja <= 10) return 0.10 * nominalGaji; // 6–10 tahun: 10% bonus
        return 0.15 * nominalGaji; // >10 tahun: 15% bonus
    }

    // Mengembalikan jumlah gaji pokok ditambah dengan bonus yang diperoleh
    public double pendapatanGaji() {
        return nominalGaji + bonusTahunan();
    }

    // Override method dari kelas manusia untuk menghitung pendapatan keseluruhan
    @Override
    public double totalPendapatan() {
        return super.totalPendapatan() + pendapatanGaji() + (20.0 * anak); // $20 per anak
    }

    // Method untuk menampilkan data pekerja secara lengkap
    @Override
    public String toString() {
        return super.toString() +
               "\nMulai Bekerja: " + tanggalMasuk +
               "\nJumlah Anak: " + anak +
               "\nPendapatan Gaji + Bonus: $" + pendapatanGaji() +
               "\nTotal Keseluruhan: $" + totalPendapatan();
    }
}
