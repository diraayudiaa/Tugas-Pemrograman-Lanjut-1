// Kelas mahasiswaFilkom adalah turunan dari kelas manusia yang merepresentasikan mahasiswa FILKOM
public class mahasiswaFilkom extends manusia {
    // untuk menyimpan NIM 
    private String nomorIndukMahasiswa;

    // untuk menyimpan nilai IPK mahasiswa
    private double indeksPrestasi;

    // Konstruktor untuk inisialisasi objek mahasiswaFilkom dengan informasi pribadi dan akademik
    public mahasiswaFilkom(String nama, boolean jk, String nik, boolean menikah, String nim, double ipk) {
        super(nama, jk, nik, menikah); // Memanggil konstruktor superclass (manusia)
        this.nomorIndukMahasiswa = nim;
        this.indeksPrestasi = ipk;
    }

    // Method untuk menentukan status akademik berdasarkan NIM (prodi dan angkatan)
    public String interpretasiStatus() {
        String hasilProdi;

        // 2 digit pertama untuk mengetahui tahun masuk (angkatan)
        int tahunMasuk = 2000 + Integer.parseInt(nomorIndukMahasiswa.substring(0, 2));

        // Karakter ke-7 menunjukkan kode prodi
        char kode = nomorIndukMahasiswa.charAt(6);

        // Menentukan nama program studi berdasarkan kode
        switch (kode) {
            case '2': hasilProdi = "Teknik Informatika"; break;
            case '3': hasilProdi = "Teknik Komputer"; break;
            case '4': hasilProdi = "Sistem Informasi"; break;
            case '6': hasilProdi = "Pendidikan Teknologi Informasi"; break;
            case '7': hasilProdi = "Teknologi Informasi"; break;
            default: hasilProdi = "Prodi tidak teridentifikasi";
        }

        return hasilProdi + ", " + tahunMasuk;
    }

    // untuk menentukan jumlah beasiswa berdasarkan IPK
    public double nilaiBeasiswa() {
        if (indeksPrestasi >= 3.5) return 75.0;        // Beasiswa maksimal untuk IPK tinggi
        else if (indeksPrestasi >= 3.0) return 50.0;   // Beasiswa sedang
        else return 0;                                 // Tidak dapat beasiswa
    }

    // Override method untuk menghitung pendapatan total (tunjangan + beasiswa)
    @Override
    public double totalPendapatan() {
        return super.totalPendapatan() + nilaiBeasiswa();
    }

    // Menampilkan informasi lengkap mahasiswa termasuk dari kelas induk
    @Override
    public String toString() {
        return super.toString() +
               "\nNIM: " + nomorIndukMahasiswa +
               "\nIPK: " + indeksPrestasi +
               "\nStatus Akademik: " + interpretasiStatus() +
               "\nPendapatan Total: $" + totalPendapatan();
    }
}

