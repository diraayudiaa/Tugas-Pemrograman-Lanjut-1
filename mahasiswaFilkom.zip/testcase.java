import java.time.LocalDate;

// main class yang digunakan untuk menjalankan semua test case dari objek-objek yang telah dibuat
public class testcase {
    public static void main(String[] args) {
        // Objek Manusia

        // Pria yang sudah menikah
        manusia lakiSudahNikah = new manusia("Andi Nugroho", true, "1234567890", true);

        // Wanita yang sudah menikah
        manusia wanitaSudahNikah = new manusia("Siti Rahma", false, "0987654321", true);

        // Perempuan yang belum menikah
        manusia singlePerempuan = new manusia("Maya Lestari", false, "1122334455", false);

        System.out.println("-- Data Manusia --");
        System.out.println(lakiSudahNikah);     // data pria menikah
        System.out.println();
        System.out.println(wanitaSudahNikah);   // data wanita menikah
        System.out.println();
        System.out.println(singlePerempuan);    // data wanita single
        System.out.println();

        // Mahasiswa, berdasarkan IPK

        // Mahasiswa IPK di bawah 3 (tidak dapat beasiswa)
        mahasiswaFilkom mhs1 = new mahasiswaFilkom("Rian", true, "1112233445", false, "225150600000001", 2.9);

        // Mahasiswa IPK antara 3.0 - 3.5 (dapat $50)
        mahasiswaFilkom mhs2 = new mahasiswaFilkom("Nadia", false, "9998877665", false, "215150700000002", 3.3);

        // Mahasiswa IPK antara 3.5 - 4.0 (dapat $75)
        mahasiswaFilkom mhs3 = new mahasiswaFilkom("Ardi", true, "5544332211", false, "195150400000003", 3.75);

        System.out.println("-- Mahasiswa FILKOM --");
        System.out.println(mhs1);   // mahasiswa IPK < 3
        System.out.println();
        System.out.println(mhs2);   // mahasiswa IPK 3 - 3.5
        System.out.println();
        System.out.println(mhs3);   // mahasiswa IPK 3.5 - 4
        System.out.println();

        // Pekerja, berdasarkan lama kerja dan jumlah anak 

        // Pekerja baru, 2 tahun kerja, punya 2 anak
        pekerja kerjaBaru = new pekerja("Putra", true, "1212121212", true, 5000, LocalDate.now().minusYears(2), 2);

        // Pekerja dengan masa kerja 9 tahun, tanpa anak
        pekerja kerjaMenengah = new pekerja("Putri", false, "3232323232", true, 6200, LocalDate.now().minusYears(9), 0);

        // Pekerja senior, 20 tahun kerja, 10 anak
        pekerja kerjaSenior = new pekerja("Radit", true, "7878787878", true, 7200, LocalDate.now().minusYears(20), 10);

        System.out.println("-- Data Pekerja --");
        System.out.println(kerjaBaru);       // pekerja 2 tahun
        System.out.println();
        System.out.println(kerjaMenengah);   // pekerja 9 tahun
        System.out.println();
        System.out.println(kerjaSenior);     // pekerja senior
        System.out.println();

        // Manager, lama kerja 15 tahun, gaji tinggi

        // Manajer dari divisi keuangan, 15 tahun pengalaman, 3 anak
        manager kepalaDivisi = new manager("Kevin", true, "1919191919", true, 7500, LocalDate.now().minusYears(15), 3, "Divisi Keuangan");

        System.out.println("-- Data Manager --");
        System.out.println(kepalaDivisi); 
    }
}

