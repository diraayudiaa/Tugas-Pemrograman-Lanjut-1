public class manusia {
    // untuk menyimpan nama lengkap 
    private String namaLengkap;

    // menyimpan informasi jenis kelamin: true untuk laki-laki, false untuk perempuan
    private boolean pria;

    // NIK
    private String nomorInduk;

    // apakah orang tersebut sudah menikah atau belum
    private boolean sudahMenikah;

    // Konstruktor: untuk membuat objek manusia dengan parameter awal
    public manusia(String nama, boolean jenisKelamin, String nik, boolean menikah) {
        this.namaLengkap = nama;
        this.pria = jenisKelamin;
        this.nomorInduk = nik;
        this.sudahMenikah = menikah;
    }

    // Method untuk menghitung tunjangan berdasarkan status pernikahan dan jenis kelamin
    public double hitungTunjangan() {
        if (sudahMenikah) {
            return pria ? 25.0 : 20.0; // pria dapat $25, wanita dapat $20
        }
        return 15.0; // yang belum menikah dapat $15
    }

    // Method untuk menghitung total pendapatan, di sini hanya berasal dari tunjangan
    public double totalPendapatan() {
        return hitungTunjangan();
    }

    // Menampilkan informasi objek manusia dalam bentuk string yang mudah dibaca
    @Override
    public String toString() {
        return "Nama: " + namaLengkap +
               "\nNIK: " + nomorInduk +
               "\nJenis Kelamin: " + (pria ? "Laki-laki" : "Perempuan") +
               "\nPendapatan: $" + totalPendapatan();
    }
}

