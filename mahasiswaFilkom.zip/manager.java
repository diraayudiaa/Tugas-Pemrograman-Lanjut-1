import java.time.LocalDate;

// class manager adalah subclass dari pekerja yang menambahkan atribut divisi
public class manager extends pekerja {
    // informasi divisi atau departemen tempat manager bekerja
    private String divisi;

    // Konstruktor untuk menginisialisasi semua atribut yang dibutuhkan, termasuk atribut dari superclass pekerja
    public manager(String nama, boolean pria, String nik, boolean menikah, double gaji, LocalDate masuk, int anak, String departemen) {
        super(nama, pria, nik, menikah, gaji, masuk, anak); // Memanggil konstruktor dari pekerja
        this.divisi = departemen;
    }

    // Override method totalPendapatan untuk menambahkan tunjangan manajerial sebesar 10% dari gaji (sebelum bonus tambahan)
    @Override
    public double totalPendapatan() {
        return super.totalPendapatan() + 0.1 * super.pendapatanGaji(); // Tunjangan manager = 10% dari gaji pokok + bonus
    }

    // Menampilkan seluruh informasi manager, termasuk informasi pekerja dan manusia yang diwarisi
    @Override
    public String toString() {
        return super.toString() +
               "\nDepartemen: " + divisi +
               "\nPendapatan Manager (dengan bonus): $" + totalPendapatan();
    }
}

