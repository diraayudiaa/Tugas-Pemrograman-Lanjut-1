import java.io.File;

public class hapusDirektori {
    public static void main(String[] args) {
        File direktori = new File("C:\\sampahDira");

        if (direktori.exists() && direktori.isDirectory()) {
            File[] files = direktori.listFiles();
            if (files != null) {
                boolean semuaFileTerhapus = true;
                for (File file : files) {
                    if (file.isFile()) {
                        try {
                            if (!file.delete()) {
                                System.err.println("Gagal menghapus file: " + file.getName());
                                semuaFileTerhapus = false;
                            } else {
                                System.out.println("File '" + file.getName() + "' berhasil dihapus.");
                            }
                        } catch (SecurityException e) {
                            System.err.println("Gagal menghapus file (SecurityException): " + file.getName() + " - " + e.getMessage());
                            semuaFileTerhapus = false;
                        }
                    }
                }

                if (semuaFileTerhapus) {
                    try {
                        if (direktori.delete()) {
                            System.out.println("Direktori '" + direktori.getName() + "' berhasil dihapus.");
                        } else {
                            System.err.println("Gagal menghapus direktori '" + direktori.getName() + "'.");
                        }
                    } catch (SecurityException e) {
                        System.err.println("Gagal menghapus direktori (SecurityException): " + direktori.getName() + " - " + e.getMessage());
                    }
                } else {
                    System.err.println("Tidak semua file di dalam direktori berhasil dihapus. Direktori tidak dihapus.");
                }
            } else {
                System.out.println("Direktori kosong.");
                try {
                    if (direktori.delete()) {
                        System.out.println("Direktori '" + direktori.getName() + "' berhasil dihapus.");
                    } else {
                        System.err.println("Gagal menghapus direktori '" + direktori.getName() + "'.");
                    }
                } catch (SecurityException e) {
                    System.err.println("Gagal menghapus direktori (SecurityException): " + direktori.getName() + " - " + e.getMessage());
                }
            }
        } else {
            System.out.println("Direktori '" + direktori.getName() + "' tidak ada atau bukan direktori.");
        }
    }
}