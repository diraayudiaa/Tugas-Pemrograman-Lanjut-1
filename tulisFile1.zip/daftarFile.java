import java.io.File;

public class daftarFile {
    public static void main(String[] args) {
        File direktori = new File("C:\\halo"); // "sampah" merepresentasikan direktori sekarang
      
        File[] files = direktori.listFiles();

        // Memeriksa apakah daftar file berhasil didapatkan (tidak null)
        if (files != null) {
            System.out.println("Daftar file di direktori " + direktori.getAbsolutePath() + ":");
            // loop untuk setiap file atau direktori dalam daftar
            for (File file : files) {
                // apakah elemen saat ini adalah sebuah file (bukan direktori)
                if (file.isFile()) {
                    System.out.println(file.getName());
                }
            }
        } else {
            // Jika gagal mendapatkan daftar file (listFiles mengembalikan null), menampilkan pesan error
            System.out.println("Gagal membaca daftar file di direktori.");
        }
    }
}