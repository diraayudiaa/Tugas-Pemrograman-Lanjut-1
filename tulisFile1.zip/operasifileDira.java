import java.io.File;
import java.text.DecimalFormat;

public class operasifileDira {
    public static void main(String[] args) {
        // Membuat objek File yang merepresentasikan file atau direktori dengan path "C:\\sampah"
        File file = new File("C:\\halo");

        // Memeriksa apakah file atau direktori yang direpresentasikan oleh objek 'file' ada
        if (file.exists()) {
            // ukuran file dalam byte
            long bytes = file.length();
            // Mengkonversi ukuran byte ke kilobyte
            double kilobytes = (double) bytes / 1024;
            // Mengkonversi ukuran kilobyte ke megabyte
            double megabytes = kilobytes / 1024;

            // Membuat objek DecimalFormat untuk memformat angka desimal dengan dua digit setelah koma
            DecimalFormat df = new DecimalFormat("#.##");

            // apakah ukuran file dalam megabyte lebih besar atau sama dengan 1
            if (megabytes >= 1) {
                System.out.println("Ukuran file: " + df.format(megabytes) + " MB");
            } else {
                System.out.println("Ukuran file: " + df.format(kilobytes) + " KB");
            }
        } else {
            // Jika file atau direktori tidak ditemukan, mencetak pesan ini
            System.out.println("File tidak ditemukan.");
        }
    }
}