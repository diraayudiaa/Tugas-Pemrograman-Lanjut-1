class employee implements Payable {
    int nomorRegistrasi;
    String nama;
    int gajiBulanan;
    Invoice[] daftarBelanjaan;

    // constructor untuk membuat objek Employee.
    employee(int nomorRegistrasi, String nama, int gajiBulanan, Invoice[] daftarBelanjaan) {
        this.nomorRegistrasi = nomorRegistrasi;
        this.nama = nama;
        this.gajiBulanan = gajiBulanan;
        this.daftarBelanjaan = daftarBelanjaan;
    }

    // untuk mendapatkan nomor registrasi karyawan.
    int dapatNomorRegistrasi() {
        return nomorRegistrasi;
    }

    // untuk mendapatkan nama karyawan.
    String dapatNama() {
        return nama;
    }

    // untuk mendapatkan gaji bulanan karyawan.
    int dapatGajiBulanan() {
        return gajiBulanan;
    }

    // untuk mendapatkan daftar belanjaan karyawan (berupa array Invoice).
    Invoice[] dapatDaftarBelanjaan() {
        return daftarBelanjaan;
    }

    // private untuk menghitung total nilai belanjaan karyawan.
    private int hitungTotalBelanja() {
        int total = 0;
        // untuk memastikan daftar belanjaan tidak null sebelum diiterasi.
        if (daftarBelanjaan != null) {
            // loop melalui setiap item belanjaan yg ada dalam daftar.
            for (Invoice item : daftarBelanjaan) {
                // menggunakan method getPayableAmount() dari objek invoice untuk mendapatkan harga total per item.
                total += item.getPayableAmount();
            }
        }
        return total;
    }

    @Override
    // implementasi dari method getPayableAmount() dari interface Payable.
    public int getPayableAmount() {
        // menghitung sisa gaji setelah dikurangi total belanjaan.
        return gajiBulanan - hitungTotalBelanja();
    }

    // untuk menampilkan informasi lengkap karyawan termasuk detail belanjaan.
    void tampilkanInfoKaryawan() {
        System.out.println("Nomor Registrasi: " + nomorRegistrasi);
        System.out.println("Nama: " + nama);
        System.out.println("Gaji Bulanan: Rp" + String.format("%,d", gajiBulanan));
        System.out.println("Total Belanja: Rp" + String.format("%,d", hitungTotalBelanja()));
        System.out.println("Sisa Gaji: Rp" + String.format("%,d", getPayableAmount()));
    
        tampilkanDetailBelanjaan();
    }

    // untuk menampilkan detail setiap item belanjaan.
    private void tampilkanDetailBelanjaan() {
        // memastikan daftar belanjaan tidak null dan tidak kosong.
        if (daftarBelanjaan != null && daftarBelanjaan.length > 0) {
            System.out.println("\nRincian Belanja:");
            // loop melalui setiap item belanjaan dan mencetaknya menggunakan representasi String dari objek Invoice.
            for (Invoice item : daftarBelanjaan) {
                System.out.println("- " + item); // mengandalkan method toString() dari kelas Invoice.
            }
        } else {
            System.out.println("\nTidak ada catatan belanja di koperasi.");
        }
    }
}