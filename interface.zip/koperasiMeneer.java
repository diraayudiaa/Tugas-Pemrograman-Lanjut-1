public class koperasiMeneer {
    public static void main(String[] args) {
        // belanjaan beberapa karyawan
        Invoice[] belanjaanAndi = {
                new Invoice("Pensil 2B", 10, 2500),
                new Invoice("Buku Tulis", 3, 15000)
        };

        Invoice[] belanjaanBella = {
                new Invoice("Kalkulator", 1, 55000)
        };

        // data karyawan
        employee andi = new employee(201, "Devi", 4800000, belanjaanAndi);
        employee bella = new employee(202, "Nofita", 5200000, belanjaanBella);
        employee charlie = new employee(203, "Amelia", 5800000, null); // Charlie belum belanja

        System.out.println("--- Gaji Karyawan Setelah Pemotongan Koperasi ---");
        System.out.println("----------------------------------------------------------");
        andi.tampilkanInfoKaryawan();
        System.out.println("\n----------------------------------------------------------");
        bella.tampilkanInfoKaryawan();
        System.out.println("\n----------------------------------------------------------");
        charlie.tampilkanInfoKaryawan();
    }
}