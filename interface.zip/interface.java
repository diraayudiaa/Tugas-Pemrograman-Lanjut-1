interface Payable {
    // interface ini mendefinisikan kontrak untuk objek yang dapat dihitung nilai pembayarannya.
    int getPayableAmount(); // Method ini harus diimplementasikan oleh kelas yang mengimplementasikan Payable.
}

class Invoice implements Payable {
    String namaBarang;
    int jumlah;
    int hargaSatuan;

    Invoice(String namaBarang, int jumlah, int hargaSatuan) {
        this.namaBarang = namaBarang;
        this.jumlah = jumlah;
        this.hargaSatuan = hargaSatuan;
    }

    String dapatNamaBarang() {
        return namaBarang;
    }

    int dapatJumlah() {
        return jumlah;
    }

    int dapatHargaSatuan() {
        return hargaSatuan;
    }

    @Override
    // implementasi dari method getPayableAmount() dari interface Payable.
    public int getPayableAmount() {
        // menghitung total harga invoice berdasarkan jumlah dan harga satuan.
        return jumlah * hargaSatuan;
    }

    @Override
    // Override method toString() untuk representasi string dari objek Invoice.
    public String toString() {
        // format string yang menampilkan nama barang, jumlah, harga satuan, dan total harga.
        return namaBarang + " (" + jumlah + " x Rp" + String.format("%,d", hargaSatuan) + ") = Rp" + String.format("%,d", getPayableAmount());
    }
}