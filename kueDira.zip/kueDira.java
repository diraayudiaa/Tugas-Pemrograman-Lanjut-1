abstract class kueDira {
    String nama; 
    double harga; 

    // konstruktor untuk class kueDira
    public kueDira(String nama, double harga) {
        this.nama = nama;
        this.harga = harga;
    }

    // method abstract untuk menghitung harga, implementasi ada di subclass
    public abstract double hitungHarga();

    // override method toString untuk representasi string objek kueDira
    @Override
    public String toString() {
        return "Nama: " + nama + ", Harga Dasar: Rp" + String.format("%.2f", harga);
    }
}

// subclass KuePesanan inheritance dari kueDira
class KuePesanan extends kueDira {
    double berat; 

    // constructor untuk class KuePesanan
    public KuePesanan(String nama, double harga, double berat) {
        super(nama, harga); // memanggil konstruktor superclass kueDira
        this.berat = berat;
    }

    // menggunakan method hitungHarga untuk KuePesanan berdasarkan berat kue
    @Override
    public double hitungHarga() {
        return harga * berat; // harga akhir dihitung dari harga dasar dikali berat
    }

    // override method toString untuk representasi string objek KuePesanan
    @Override
    public String toString() {
        return "Kue Pesanan - " + super.toString() + ", Berat: " + berat + " kg, Harga Akhir: Rp" + String.format("%.2f", hitungHarga());
    }
}

// subclass KueJadi inheritance dari kueDira
class KueJadi extends kueDira {
    int jumlah; 

    // constructor untuk kelas KueJadi
    public KueJadi(String nama, double harga, int jumlah) {
        super(nama, harga); // memanggil konstruktor superclass kueDira
        this.jumlah = jumlah;
    }

    // menggunakan method hitungHarga untuk KueJadi berdasarkan jumlah
    @Override
    public double hitungHarga() {
        return harga * jumlah * 2; // harga akhir dihitung dari harga dasar dikali jumlah dikali 2
    }

    // override method toString untuk representasi string objek KueJadi
    @Override
    public String toString() {
        return "Kue Jadi - " + super.toString() + ", Jumlah: " + jumlah + " buah, Harga Akhir: Rp" + String.format("%.2f", hitungHarga());
    }
}