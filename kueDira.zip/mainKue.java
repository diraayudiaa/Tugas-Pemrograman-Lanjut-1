import java.util.ArrayList;
import java.util.List;
public class mainKue {
    public static void main(String[] args) {
        // array isinya ada 20 kue
        List<kueDira> daftarKue = new ArrayList<>();

        // mengisi array dengan jenis jenis kue
        daftarKue.add(new KuePesanan("Brownies Coklat", 25000, 1.5)); 
        daftarKue.add(new KueJadi("Donat Keju", 8000, 10)); 
        daftarKue.add(new KuePesanan("Black Forest", 50000, 2)); 
        daftarKue.add(new KueJadi("Kue Lumpur", 5000, 15)); 
        daftarKue.add(new KuePesanan("Lapis Surabaya", 30000, 1.2)); 
        daftarKue.add(new KueJadi("Bolu Kukus", 6000, 20)); 
        daftarKue.add(new KuePesanan("Cheese Cake", 45000, 0.8)); 
        daftarKue.add(new KueJadi("Muffin Coklat", 7000, 12)); 
        daftarKue.add(new KuePesanan("Red Velvet", 55000, 1.7)); 
        daftarKue.add(new KueJadi("Sus Vla", 9000, 18)); 
        daftarKue.add(new KuePesanan("Kue Tart Ulang Tahun", 75000, 2.5)); 
        daftarKue.add(new KueJadi("Roti Tawar", 12000, 5)); 
        daftarKue.add(new KuePesanan("Macaroon", 15000, 0.5)); 
        daftarKue.add(new KueJadi("Croissant", 10000, 8)); 
        daftarKue.add(new KuePesanan("Pie Susu", 20000, 1)); 
        daftarKue.add(new KueJadi("Pastel Isi", 4000, 25));
        daftarKue.add(new KuePesanan("Bolu Gulung", 35000, 1.3)); 
        daftarKue.add(new KueJadi("Kue Mangkok", 3000, 30)); 
        daftarKue.add(new KuePesanan("Sponge Cake", 40000, 1.1)); 
        daftarKue.add(new KueJadi("Getuk Lindri", 2500, 40)); 

        System.out.println("--- Daftar Semua Kue ---"); 
        double totalHargaSemuaKue = 0; // untuk menyimpan total harga semua kue
        for (kueDira kue : daftarKue) { // loop dari setiap objek kue dalam daftar
            System.out.println(kue); 
            totalHargaSemuaKue += kue.hitungHarga(); // nambahin harga kue ssekarang ke total harga
        }
        System.out.println("Total Harga Semua Kue: Rp" + String.format("%.2f", totalHargaSemuaKue)); // total harga semua kue
        System.out.println(); 

        System.out.println("--- Kue Pesanan ---"); 
        double totalHargaKuePesanan = 0; // untuk menyimpan total harga kue pesanan
        double totalBeratKuePesanan = 0; // untuk menyimpan total berat kue pesanan
        for (kueDira kue : daftarKue) { // loop dari setiap objek kue dalam daftar
            if (kue instanceof KuePesanan) { //  apakah objek kue adalah turunan dari class KuePesanan
                KuePesanan kuePesanan = (KuePesanan) kue; 
                System.out.println(kuePesanan); 
                totalHargaKuePesanan += kuePesanan.hitungHarga(); // nambahin harga kue pesanan ke total harga kue pesanan
                totalBeratKuePesanan += kuePesanan.berat; // nambahin berat kue pesanan ke total berat kue pesanan
            }
        }
        System.out.println("Total Harga Kue Pesanan: Rp" + String.format("%.2f", totalHargaKuePesanan)); // total harga kue pesanan
        System.out.println("Total Berat Kue Pesanan: " + String.format("%.2f", totalBeratKuePesanan) + " kg"); // total berat kue pesanan
        System.out.println(); 

        System.out.println("--- Kue Jadi ---"); 
        double totalHargaKueJadi = 0; // untuk menyimpan total harga kue jadi
        int totalJumlahKueJadi = 0; // untuk menyimpan total jumlah kue jadi
        for (kueDira kue : daftarKue) { // loop dari setiap objek kue dalam daftar
            if (kue instanceof KueJadi) { // apakah objek kue adalah turunan dari kelas KueJadi
                KueJadi kueJadi = (KueJadi) kue;
                System.out.println(kueJadi); 
                totalHargaKueJadi += kueJadi.hitungHarga(); // tambahkan harga kue jadi ke total harga kue jadi
                totalJumlahKueJadi += kueJadi.jumlah; // tambahkan jumlah kue jadi ke total jumlah kue jadi
            }
        }
        System.out.println("Total Harga Kue Jadi: Rp" + String.format("%.2f", totalHargaKueJadi)); // total harga kue jadi
        System.out.println("Total Jumlah Kue Jadi: " + totalJumlahKueJadi + " buah"); // total jumlah kue jadi
        System.out.println(); 

        System.out.println("--- Kue dengan Harga Terbesar ---"); 
        kueDira kueHargaTerbesar = null; // untuk menyimpan objek kue dengan harga terbesar
        double hargaTerbesar = -1; // untuk menyimpan harga terbesar yang ditemukan
        for (kueDira kue : daftarKue) { // loop dari setiap objek kue dalam daftar
            if (kue.hitungHarga() > hargaTerbesar) { // apakah harga kue sekarang lebih besar dari harga yang paling besar
                hargaTerbesar = kue.hitungHarga(); // update harga terbesar
                kueHargaTerbesar = kue; // update objek kue dengan harga terbesar
            }
        }
        if (kueHargaTerbesar != null) { // apakah ada kue dengan harga paling besar yang ditemukan
            System.out.println(kueHargaTerbesar); 
        }
    }
}